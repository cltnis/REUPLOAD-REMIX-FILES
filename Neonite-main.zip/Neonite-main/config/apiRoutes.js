module.exports.routes = {
    'GET /launcher/api/public/distributionpoints': 'ApiController.distributionPoints',
    'GET /launcher/api/public/assets/:platform/:catalogItemId/:appName': 'ApiController.launcherCatalogItem',
    'GET /Builds/Fortnite/Content/CloudDir/*.manifest': {
        action: "manifest",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /Builds/Fortnite/Content/CloudDir/*.ini': 'ApiController.ini',
    'GET /Builds/Fortnite/Content/CloudDir/ChunksV4/:chunknum/:chunkFile': {
        action: "ChunksV4",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /lightswitch/api/service/bulk/status': 'ApiController.lightSwitchBulk',
    'GET /lightswitch/api/service/:serviceId/status': 'ApiController.lightswitch',
    'ALL /api/v1/events/Fortnite/:event/history/:accountId': 'ApiController.eventHistory',
    'GET /fortnite/api/v2/versioncheck*': 'ApiController.versionCheck',
    'GET /fortnite/api/versioncheck*': 'ApiController.versionCheck',
    'GET /fortnite/api/version': 'ApiController.versionCheck',
    'GET /fortnite/api/game/v2/privacy/account/:accountId': 'ApiController.privacy',
    'POST /api/v1/assets/Fortnite/:version/:netcl': 'ApiController.dataAsset',
    'POST /api/v1/assets/Fortnite/:version/:netcl/FortPlaylistAthena/:playlistId': 'ApiController.dataAssetFortPlaylist',
    'GET /fortnite/api/storefront/v2/catalog': 'ApiController.catalog',
    'GET /catalog/api/shared/bulk/offers': 'ApiController.catalogBulk',
    'POST /catalog/api/shared/namespace/fn/bulk/offers': 'ApiController.catalogBulk',
    'POST /fortnite/api/game/v2/grant_access/:accountId': 'ApiController.noContent',
    'GET /fortnite/api/game/v2/enabled_features': 'ApiController.enabledFeatures',
    'POST /datarouter/api/v1/public/data': {
        action: "noContent",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /presence/api/v1/_/:accountId/settings/subscriptions': 'ApiController.noContent',
    'GET /socialban/api/public/v1/:accountId': {
        action: "socialban",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /eulatracking/api/public/agreements/*': {
        action: "noContent",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /eulatracking/api/shared/agreements/*': {
        action: "noContent",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /fortnite/api/game/v2/creative/*': {
        action: "creative",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /affiliate/api/public/affiliates/slug/:affiliateName': 'ApiController.sac',
    'GET /content-controls/:accountId': 'ApiController.contentControls',
    'GET /content-controls/:accountId/rules/namespaces/fn': 'ApiController.noContent',
    'POST /content-controls/:accountId/verify-pin': 'ApiController.verifyPin',
    'GET /api/v2/interactions/aggregated/Fortnite/:accountId': 'ApiController.noContent',
    'POST /fortnite/api/game/v2/profileToken/verify/*': {
        action: "noContent",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /api/v1/namespace/fn/worlds/accessibleTo/:accountId': 'ApiController.fetchLegoWorlds',
    'POST /api/v1/namespace/fn/worlds/account/:accountId': 'ApiController.makeLegoWorlds',
    'GET /api/v1/namespace/fn/worlds/world/:worldID/session': 'ApiController.legoWorldSession',
    'GET /api/v1/namespace/fn/worlds/world/:worldId/attest/:accountId': 'ApiController.legoMatchMakingToken',
    'GET /fortnite/api/storefront/v2/keychain': 'ApiController.keychain',
    'GET /fortnite/api/game/v2/world/info': 'ApiController.worldInfo',
    'POST /region/check': 'ApiController.regionCheck',
    'PUT /profile/play_region': 'ApiController.noContent',
    'GET /salesEvent/salesEvent/*': {
        action: "salesEvent",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /gameRating/gameRating/*': {
        action: "gameRating",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /ias/fortnite/:Hash': {
        action: "ias",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /ias/fortnite/chunks/:chunkNum/:chunkFile': {
        action: "iasChunks",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /iad/fortnite/chunks/:chunkNum/:chunkFile': {
        action: "iasChunks",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /:hash/:trackHash/*.mp4': {
        action: "trackSegment",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /:hash/:trackHash/*.m4s': {
        action: "trackSegment",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /api/v2/interactions/latest/Fortnite/:accountId': 'ApiController.interactions',
    'POST /fortnite/api/game/v2/tryPlayOnPlatform/account/:accountId': 'ApiController.tryPlayOnPlatform',
    'PUT /profile/privacy_settings': 'ApiController.privacySettings',
    'GET /api/v1/leaderboards/Fortnite/:eventId/:eventWindowId/*': {
        action: "leaderboards",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /api/v1/events/Fortnite/download/:accountId': {
        action: "eventsDownload",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /region': 'ApiController.region',
    'GET /fortnite/api/game/v2/br-inventory/account/:accountId': 'ApiController.brInventory',
    'GET /fortnite/api/storeaccess/v1/request_access/:accountId': 'ApiController.noContent',
    'GET /api/v1/lfg/Fortnite/users/:accountId/settings': 'ApiController.lfgSettings',
    'GET /followers/api/v1/FortniteLive/:accountId/*': {
        action: "followers",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /api/content/v2/launch-data': 'ApiController.noContent',
    'GET /api/content/v4/launch-data': 'ApiController.noContent',
    'POST /api/v1/user/setting': 'ApiController.userSetting',
    'OPTIONS /v1/epic-settings/public/users/:accountId/*': {
        action: "noContent",
        controller: 'ApiController',
        skipAssets: false
    },
    'PATCH /v1/epic-settings/public/users/:accountId/*': {
        action: "epicSettings",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /v1/epic-settings/public/users/:accountId/*': {
        action: "epicSettings",
        controller: 'ApiController',
        skipAssets: false
    },
    'PUT /profile/languages': 'ApiController.okStatus',
    'GET /:resourceId/master.blurl': 'ApiController.blurl',
    'GET /app_installation/status': 'ApiController.postPartyInstallStatus',
    'GET /content/api/pages/fortnite-game/spark-tracks': 'ApiController.sparks',
    'GET /content/api/pages/fortnite-game/eventscreens': 'ApiController.eventScreen',
    'GET /content/api/pages/fortnite-game/seasonpasses': 'ApiController.seasonPass',
    'GET /api/quest/v3/:deploymentId/progress/account/:accountId': 'ApiController.questProgress',
    'POST /fortnite/api/game/v2/profile/:accountId/client/:command': 'ProfileController.mcp',
    'POST /fortnite/api/game/v2/profile/:accountId/dedicated_server/:command': 'ProfileController.mcp',
    'GET /content/api/pages/fortnite-game': 'FortniteGameController.fortniteGame',
    'GET /content/api/pages/fortnite-game/radio-stations': 'FortniteGameController.stations',
    'GET /:trackdata': 'ApiController.trackData',
    'GET /:sparksTrack.dat': {
        action: "sparksTrack",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /:sparksLipSyncData.lad': {
        action: "sparksLipSyncData",
        controller: 'ApiController',
        skipAssets: false
    },
    'GET /v1/item/*': {
        action: "cosmoFdeb",
        controller: 'ApiController',
        skipAssets: false
    },
    //'GET /api/v1/Fortnite/get': 'ApiController.interactions',
    'POST /api/v1/fortnite-br/surfaces/:gameMode/target': 'FortniteGameController.motd',
    'POST /api/v1/fortnite-br/channel/motd/target': 'FortniteGameController.motdTarget',
    'POST /api/v1/fortnite-br/interactions/contentHash': 'FortniteGameController.contentHash',
    'GET /fortnite/api/calendar/v1/timeline': 'TimelineController.timeline',
    'GET /api/content/v2/link/:linkId/cooked-content-package': 'ApiController.contentLinkPackage',
    'GET /api/content/v4/link/:linkId/cooked-content-package': 'ApiController.contentLinkPackage',
    'GET /valkyrie/cooked-content/:projectId/:fnVersion/:v/:cookJob/alt/ChunksV4/:chunknum/:chunkFile': {
        controller: 'ApiController',
        action: 'cookedContentChunk',
        skipAssets: false
    },
    'GET /valkyrie/cooked-content/:projectId/:fnVersion/:v/:cookJob/alt/*.manifest': {
        controller: 'ApiController',
        action: 'cookedContentPlugin',
        skipAssets: false
    },
    'GET /api/v1/games/fortnite/tracks/activeBy/*': {
        controller: 'ApiController',
        action: 'noContent',
        skipAssets: false
    },
    'GET /api/v1/games/fortnite/trackprogress/*': {
        controller: 'ApiController',
        action: 'noContent',
        skipAssets: false
    },
    'GET /api/v1/games/fortnite/tracks/query*': 'ApiController.noContent',
    'GET /api/v1/public/accounts': 'ApiController.publicAccounts',
    'POST /api/v1/fortnite-br/interactions': 'ApiController.okStatus',
    'POST /api/v1/fortnite-br/channel/interstitials/target': 'ApiController.noContent',
    'GET /api/v1/players/Fortnite/tokens': 'ApiController.playerTokens',
    'GET /api/community/v1/fn-client/community-highlights': 'ApiController.noContent',
    'GET /mesh/Fortnite/Fortnite.Hera_Terrain.51188288/metadata': 'ApiController.heraMesh',
    'GET /mesh/Fortnite/Fortnite.Hera_Terrain.51618937/metadata': 'ApiController.heraMesh',
    'GET /mesh/Fortnite/Fortnite.Hera_Terrain.51979515/metadata': 'ApiController.heraMesh',
    'GET /mesh/Fortnite/Fortnite.Hera_Terrain.52515996/metadata': 'ApiController.heraMesh',
    'GET /mesh/Fortnite/Fortnite.Hera_Terrain.52998544/metadata': 'ApiController.heraMesh',
    'GET /mesh/Fortnite/Fortnite.Artemis_Terrain.22935214/metadata': 'ApiController.downtimeMeshNetwork',
    'GET /mesh/Fortnite/Fortnite.Artemis_Terrain.20133078/metadata': 'ApiController.downtimeMeshNetwork',
    'GET /mesh/Fortnite/Fortnite.Apollo_Terrain.14675445/metadata': 'ApiController.downtimeMeshNetwork',
    'GET /mesh/Fortnite/Fortnite.Apollo_Terrain.18045599/metadata': 'ApiController.downtimeMeshNetwork',
    'GET /cdn2-unrealengine/:image': {
        controller: 'ApiController',
        action: 'cdnImages',
        skipAssets: false
    },
    'GET /api/magpie/v2/deployment/:deploymentId/domain/FN1/account/:accountId/workspace/default/linkMode/live/inventory': {
        controller: 'ApiController',
        action: 'magpieInventory',
        skipAssets: false
    },
};